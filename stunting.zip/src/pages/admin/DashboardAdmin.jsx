// src/pages/admin/DashboardAdmin.jsx
import { useState } from "react";
import { Link } from "react-router-dom";
import {
  Table2,
  ShieldCheck,
  Contact,
  CircleCheck,
  Users,
  LayoutGrid,
  TrendingUp,
  UserCog,
  ArrowRight,
} from "lucide-react";

/* ------------------------------------------------------------------ */
/* Path route (sesuaikan dengan konfigurasi router tim)                 */
/* ------------------------------------------------------------------ */
const ROUTES = {
  dataset: "/admin/kelola-dataset",
  evaluasi: "/admin/evaluasi",
  pengguna: "/admin/kelola-pengguna",
};

/* ------------------------------------------------------------------ */
/* Mock data                                                           */
/* ------------------------------------------------------------------ */
const MOCK_STATS = {
  totalDataLatih: 12840,
  akurasiTerakhir: 94.8,
  penggunaTerdaftar: 5,
};

const MOCK_MODUL = [
  {
    id: 1,
    judul: "Kelola Dataset Balita",
    deskripsi:
      "Unggah data CSV antropometri, pengecekan missing value, dan normalisasi Z-Score balita.",
    cta: "Buka Data",
    to: ROUTES.dataset,
    icon: Table2,
  },
  {
    id: 2,
    judul: "Evaluasi Model Random Forest",
    deskripsi:
      "Tinjau visualisasi confusion matrix, precision-recall, dan kurva ROC hasil pengujian.",
    cta: "Lihat Evaluasi",
    to: ROUTES.evaluasi,
    icon: TrendingUp,
  },
  {
    id: 3,
    judul: "Kelola Akun Pengguna",
    deskripsi:
      "Konfigurasi kredensial login akun admin serta kader posyandu tingkat kelurahan.",
    cta: "Kelola Akun",
    to: ROUTES.pengguna,
    icon: UserCog,
  },
];

const fmt = new Intl.NumberFormat("id-ID");

/* ------------------------------------------------------------------ */
/* Sub-komponen lokal                                                  */
/* ------------------------------------------------------------------ */
function StatCard({ label, value, valueCls = "text-slate-900", caption, icon: Icon, footer }) {
  return (
    <div className="flex flex-col rounded-2xl border border-slate-100 bg-white p-6 shadow-sm">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-600">{label}</p>
          <p className={`mt-3 text-4xl font-bold ${valueCls}`}>{value}</p>
          <p className="mt-1 text-sm text-slate-600">{caption}</p>
        </div>
        <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-teal-50 text-teal-700">
          <Icon className="h-6 w-6" />
        </span>
      </div>
      {footer && <div className="mt-auto border-t border-slate-100 pt-4">{footer}</div>}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Halaman                                                             */
/* ------------------------------------------------------------------ */
export default function DashboardAdmin() {
  const [stats] = useState(MOCK_STATS);
  const [modul] = useState(MOCK_MODUL);

  return (
    <div className="space-y-6">
      {/* Header */}
      <section className="rounded-2xl border border-slate-100 bg-white px-6 py-5 shadow-sm">
        <span className="inline-block rounded-md bg-teal-50 px-3 py-1 text-[11px] font-bold uppercase tracking-wide text-teal-800">
          Dashboard Administrasi
        </span>
        <h1 className="mt-3 text-2xl font-bold text-slate-900">Selamat Datang, Admin & Peneliti</h1>
      </section>

      {/* Kartu statistik */}
      <section className="grid gap-4 md:grid-cols-3">
        <StatCard
          label="Total Data Latih"
          value={fmt.format(stats.totalDataLatih)}
          caption="Baris Data"
          icon={Table2}
          footer={
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <span className="inline-flex items-center gap-1.5 rounded-md bg-teal-50 px-2 py-1 font-semibold text-teal-800">
                <CircleCheck className="h-3.5 w-3.5" />
                Format CSV Bersih
              </span>
              <span className="text-slate-500">Sumber Posyandu Wilayah</span>
            </div>
          }
        />
        <StatCard
          label="Akurasi Model Terakhir"
          value={`${stats.akurasiTerakhir.toFixed(1)}%`}
          valueCls="text-teal-700"
          caption="Pengujian Data Uji"
          icon={ShieldCheck}
        />
        <StatCard
          label="Pengguna Terdaftar"
          value={stats.penggunaTerdaftar}
          caption="Akun Aktif"
          icon={Contact}
          footer={
            <span className="inline-flex items-center gap-1.5 rounded-md bg-slate-50 px-2 py-1 text-xs font-semibold text-teal-800">
              <Users className="h-3.5 w-3.5" />
              Role: Admin & Kader Posyandu
            </span>
          }
        />
      </section>

      {/* Akses cepat */}
      <section className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm">
        <div className="flex items-start justify-between gap-3 border-b border-slate-100 pb-5">
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-teal-50 text-teal-700">
              <LayoutGrid className="h-5 w-5" />
            </span>
            <div>
              <h2 className="text-lg font-bold text-slate-900">Akses Cepat Modul Utama</h2>
              <p className="text-xs text-slate-500">
                Menu interaktif untuk demonstrasi langsung saat sesi tanya jawab sidang
              </p>
            </div>
          </div>
          <span className="shrink-0 rounded-full bg-slate-100 px-3 py-1 text-[11px] font-semibold text-slate-600">
            {modul.length} Fitur Inti
          </span>
        </div>

        <ul className="mt-5 space-y-4">
          {modul.map((m) => {
            const Icon = m.icon;
            return (
              <li
                key={m.id}
                className="flex flex-col gap-4 rounded-xl border border-slate-100 bg-slate-50/60 p-5 sm:flex-row sm:items-center sm:justify-between"
              >
                <div className="flex items-start gap-4">
                  <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-teal-700 text-white">
                    <Icon className="h-6 w-6" />
                  </span>
                  <div className="max-w-xl">
                    <h3 className="text-base font-bold text-slate-900">
                      {m.id}. {m.judul}
                    </h3>
                    <p className="mt-1 text-sm text-slate-600">{m.deskripsi}</p>
                  </div>
                </div>

                <Link
                  to={m.to}
                  className="inline-flex shrink-0 items-center justify-center gap-2 rounded-lg bg-teal-800 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-teal-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-700 focus-visible:ring-offset-2"
                >
                  {m.cta}
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </li>
            );
          })}
        </ul>
      </section>
    </div>
  );
}
