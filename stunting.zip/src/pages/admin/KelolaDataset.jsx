// src/pages/admin/KelolaDataset.jsx
import { useMemo, useRef, useState } from "react";
import {
  Download,
  FileUp,
  Users,
  SlidersHorizontal,
  Check,
  CircleCheck,
  Search,
  RotateCw,
  FileText,
  Table2,
  Eye,
  Mars,
  Venus,
  ArrowLeft,
  ArrowRight,
} from "lucide-react";

/* ------------------------------------------------------------------ */
/* Style status                                                        */
/* ------------------------------------------------------------------ */
const RISIKO_BADGE = {
  Tinggi: "bg-red-50 text-red-700",
  Sedang: "bg-amber-50 text-amber-700",
  Rendah: "bg-teal-50 text-teal-700",
};

const SORT_OPTIONS = [
  { value: "id-asc", label: "ID Balita (A-Z)" },
  { value: "id-desc", label: "ID Balita (Z-A)" },
  { value: "usia-asc", label: "Usia (Termuda)" },
  { value: "usia-desc", label: "Usia (Tertua)" },
];

const KATEGORI_OPTIONS = ["Semua Kategori Risiko", "Tinggi", "Sedang", "Rendah"];

/* ------------------------------------------------------------------ */
/* Mock data                                                           */
/* ------------------------------------------------------------------ */
const MOCK_SUMMARY = {
  totalData: 12840,
  jumlahFitur: 6,
  statusDataset: "Siap Latih",
  pageSize: 5,
};

const MOCK_BALITA = [
  { id: "BLT-001", kepalaKeluarga: "Ahmad Fauzi", usia: 12, jk: "L", sanitasi: "Tidak Layak (BABS)", sanitasiLayak: false, air: "Sumur Terbuka", risiko: "Tinggi" },
  { id: "BLT-002", kepalaKeluarga: "Siti Aminah", usia: 18, jk: "P", sanitasi: "Layak Bersama", sanitasiLayak: true, air: "Sumur Bor Terlindung", risiko: "Tinggi" },
  { id: "BLT-003", kepalaKeluarga: "Budi Santoso", usia: 24, jk: "L", sanitasi: "Layak Sendiri", sanitasiLayak: true, air: "Mata Air Terlindung", risiko: "Sedang" },
  { id: "BLT-004", kepalaKeluarga: "Rina Marlina", usia: 15, jk: "P", sanitasi: "Layak Sendiri", sanitasiLayak: true, air: "PDAM / Perpipaan", risiko: "Rendah" },
  { id: "BLT-005", kepalaKeluarga: "Dedi Kurniawan", usia: 9, jk: "L", sanitasi: "Tidak Layak (Plengsengan)", sanitasiLayak: false, air: "Sumur Terbuka", risiko: "Tinggi" },
];

const fmt = new Intl.NumberFormat("id-ID");

/* Daftar halaman: 1 2 3 … last (atau jendela di sekitar halaman aktif) */
function buildPages(current, total) {
  if (total <= 5) return Array.from({ length: total }, (_, i) => i + 1);
  if (current <= 3) return [1, 2, 3, "…", total];
  if (current >= total - 2) return [1, "…", total - 2, total - 1, total];
  return [1, "…", current - 1, current, current + 1, "…", total];
}

/* ------------------------------------------------------------------ */
/* Sub-komponen lokal                                                  */
/* ------------------------------------------------------------------ */
function InfoChip({ icon: Icon, children }) {
  return (
    <span className="inline-flex items-center gap-2 rounded-lg bg-teal-50 px-3 py-1.5 text-xs font-semibold text-teal-800">
      <Icon className="h-4 w-4" />
      {children}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/* Halaman                                                             */
/* ------------------------------------------------------------------ */
export default function KelolaDataset() {
  const [summary] = useState(MOCK_SUMMARY);
  const [balita] = useState(MOCK_BALITA);

  const [query, setQuery] = useState("");
  const [kategori, setKategori] = useState(KATEGORI_OPTIONS[0]);
  const [urutan, setUrutan] = useState("id-asc");
  const [page, setPage] = useState(1);
  const [fileName, setFileName] = useState("");
  const fileRef = useRef(null);

  const totalPages = Math.ceil(summary.totalData / summary.pageSize);

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    const filtered = balita.filter((b) => {
      const cocokQuery =
        !q || b.id.toLowerCase().includes(q) || b.kepalaKeluarga.toLowerCase().includes(q);
      const cocokKategori = kategori === KATEGORI_OPTIONS[0] || b.risiko === kategori;
      return cocokQuery && cocokKategori;
    });

    return [...filtered].sort((a, b) => {
      switch (urutan) {
        case "id-desc":
          return b.id.localeCompare(a.id);
        case "usia-asc":
          return a.usia - b.usia;
        case "usia-desc":
          return b.usia - a.usia;
        default:
          return a.id.localeCompare(b.id);
      }
    });
  }, [balita, query, kategori, urutan]);

  const resetFilter = () => {
    setQuery("");
    setKategori(KATEGORI_OPTIONS[0]);
    setUrutan("id-asc");
    setPage(1);
  };

  const handleDownloadTemplate = () => {
    // TODO: sambungkan ke endpoint template CSV
    console.log("Unduh template CSV");
  };

  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    // TODO: kirim file ke endpoint upload (FormData) lalu muat ulang data
  };

  const handleView = (row) => {
    // TODO: buka modal / halaman detail balita
    console.log("Lihat detail", row.id);
  };

  const goTo = (p) => setPage(Math.min(Math.max(p, 1), totalPages));

  return (
    <div className="space-y-6">
      {/* Header */}
      <section className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Pengelolaan Dataset Balita</h1>
          <p className="mt-1 text-sm text-slate-500">
            Data antropometri dan faktor risiko stunting balita untuk pelatihan algoritma Random
            Forest.
          </p>
          {fileName && (
            <p className="mt-2 flex items-center gap-2 text-xs font-semibold text-teal-700">
              <FileText className="h-4 w-4" />
              File dipilih: {fileName}
            </p>
          )}
        </div>

        <div className="flex flex-wrap gap-3">
          <button
            type="button"
            onClick={handleDownloadTemplate}
            className="inline-flex items-center gap-2 rounded-xl bg-teal-50 px-4 py-2.5 text-sm font-semibold text-teal-800 transition hover:bg-teal-100 focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-700 focus-visible:ring-offset-2"
          >
            <Download className="h-4 w-4" />
            Unduh Template CSV
          </button>
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            className="inline-flex items-center gap-2 rounded-xl bg-teal-800 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-teal-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-700 focus-visible:ring-offset-2"
          >
            <FileUp className="h-4 w-4" />
            Unggah Dataset (.CSV)
          </button>
          <input
            ref={fileRef}
            type="file"
            accept=".csv,text/csv"
            onChange={handleFileChange}
            className="hidden"
          />
        </div>
      </section>

      {/* Kartu ringkasan */}
      <section className="grid gap-4 lg:grid-cols-3">
        <div className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-600">
                Total Data Tersimpan
              </p>
              <p className="mt-3 text-4xl font-bold text-slate-900">
                {fmt.format(summary.totalData)}{" "}
                <span className="text-sm font-medium text-slate-500">Balita / Baris</span>
              </p>
            </div>
            <Users className="h-6 w-6 text-slate-700" />
          </div>
          <p className="mt-5 flex items-center gap-2 text-xs font-semibold text-slate-700">
            <CircleCheck className="h-4 w-4" />
            100% Lengkap (Tanpa Missing Value)
          </p>
        </div>

        <div className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-600">
                Jumlah Fitur / Variabel
              </p>
              <p className="mt-3 text-4xl font-bold text-slate-900">
                {summary.jumlahFitur}{" "}
                <span className="text-sm font-medium text-slate-500">Fitur Masukan</span>
              </p>
            </div>
            <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-teal-50 text-teal-700">
              <SlidersHorizontal className="h-5 w-5" />
            </span>
          </div>
          <div className="mt-5">
            <InfoChip icon={CircleCheck}>Tervalidasi Akademik (Z-Score TB/U)</InfoChip>
          </div>
        </div>

        <div className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-600">
                Status Dataset
              </p>
              <p className="mt-3 text-4xl font-bold text-teal-700">{summary.statusDataset}</p>
            </div>
            <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-teal-50 text-teal-700">
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-teal-700 text-white">
                <Check className="h-4 w-4" />
              </span>
            </span>
          </div>
          <div className="mt-5">
            <InfoChip icon={CircleCheck}>Telah Melalui Normalisasi & Imputasi</InfoChip>
          </div>
        </div>
      </section>

      {/* Filter */}
      <section className="rounded-2xl border border-slate-100 bg-white p-4 shadow-sm">
        <div className="flex flex-col gap-3 xl:flex-row xl:items-center">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="search"
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                setPage(1);
              }}
              placeholder="Cari ID Balita atau nama kepala keluarga..."
              aria-label="Cari data balita"
              className="w-full rounded-xl bg-slate-50 py-2.5 pl-10 pr-4 text-sm text-slate-700 placeholder:text-slate-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-700"
            />
          </div>

          <label className="flex items-center gap-2 text-xs font-semibold text-slate-600">
            Kategori:
            <select
              value={kategori}
              onChange={(e) => {
                setKategori(e.target.value);
                setPage(1);
              }}
              className="rounded-xl bg-slate-50 px-3 py-2.5 text-xs font-bold text-slate-800 focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-700"
            >
              {KATEGORI_OPTIONS.map((k) => (
                <option key={k}>{k}</option>
              ))}
            </select>
          </label>

          <label className="flex items-center gap-2 text-xs font-semibold text-slate-600">
            Urutan:
            <select
              value={urutan}
              onChange={(e) => setUrutan(e.target.value)}
              className="rounded-xl bg-slate-50 px-3 py-2.5 text-xs font-bold text-slate-800 focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-700"
            >
              {SORT_OPTIONS.map((o) => (
                <option key={o.value} value={o.value}>
                  {o.label}
                </option>
              ))}
            </select>
          </label>

          <div className="flex items-center gap-2 xl:ml-auto">
            <span className="inline-flex items-center gap-1.5 rounded-lg bg-teal-50 px-3 py-2 text-[11px] font-semibold text-teal-800">
              <FileText className="h-3.5 w-3.5" />
              Format: UTF-8 CSV
            </span>
            <button
              type="button"
              onClick={resetFilter}
              aria-label="Atur ulang filter"
              className="flex h-9 w-9 items-center justify-center rounded-lg bg-slate-50 text-slate-700 transition hover:bg-slate-100 focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-700"
            >
              <RotateCw className="h-4 w-4" />
            </button>
          </div>
        </div>
      </section>

      {/* Tabel pratinjau */}
      <section className="overflow-hidden rounded-2xl border border-slate-100 bg-white shadow-sm">
        <div className="flex items-center justify-between gap-3 bg-sky-50/70 px-6 py-4">
          <h2 className="flex items-center gap-2 text-base font-bold text-slate-900">
            <Table2 className="h-5 w-5 text-teal-700" />
            Pratinjau Data Primer Antropometri
          </h2>
          <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
            Sampel Head ({summary.pageSize} Baris Teratas)
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[860px] text-left text-sm">
            <thead>
              <tr className="bg-sky-50/70 text-[11px] font-bold uppercase tracking-wide text-slate-600">
                <th scope="col" className="px-6 py-3">No</th>
                <th scope="col" className="px-3 py-3">ID Balita</th>
                <th scope="col" className="px-3 py-3">Usia (Bulan)</th>
                <th scope="col" className="px-3 py-3">Jenis Kelamin</th>
                <th scope="col" className="px-3 py-3">Sanitasi Jamban</th>
                <th scope="col" className="px-3 py-3">Sumber Air Bersih</th>
                <th scope="col" className="px-3 py-3">Status Risiko</th>
                <th scope="col" className="px-6 py-3 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {rows.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-6 py-10 text-center text-sm text-slate-500">
                    Tidak ada data yang cocok. Ubah kata kunci atau atur ulang filter.
                  </td>
                </tr>
              )}
              {rows.map((b, i) => (
                <tr key={b.id} className="hover:bg-slate-50/60">
                  <td className="px-6 py-4 text-slate-500">{(page - 1) * summary.pageSize + i + 1}</td>
                  <td className="px-3 py-4 font-bold text-teal-700">{b.id}</td>
                  <td className="px-3 py-4 text-slate-700">{b.usia} Bulan</td>
                  <td className="px-3 py-4 text-slate-700">
                    <span className="inline-flex items-center gap-1.5">
                      {b.jk === "L" ? (
                        <Mars className="h-4 w-4 text-teal-700" />
                      ) : (
                        <Venus className="h-4 w-4 text-rose-500" />
                      )}
                      {b.jk === "L" ? "Laki-laki" : "Perempuan"}
                    </span>
                  </td>
                  <td className="px-3 py-4">
                    <span
                      className={
                        b.sanitasiLayak
                          ? "text-xs font-medium text-slate-700"
                          : "rounded-md bg-red-100 px-2 py-1 text-xs font-medium text-red-700"
                      }
                    >
                      {b.sanitasi}
                    </span>
                  </td>
                  <td className="px-3 py-4 text-slate-700">{b.air}</td>
                  <td className="px-3 py-4">
                    <span
                      className={`rounded-full px-2.5 py-1 text-xs font-bold ${RISIKO_BADGE[b.risiko]}`}
                    >
                      Risiko {b.risiko}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button
                      type="button"
                      onClick={() => handleView(b)}
                      aria-label={`Lihat detail ${b.id}`}
                      className="rounded-md p-1.5 text-slate-500 transition hover:bg-slate-100 hover:text-teal-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-700"
                    >
                      <Eye className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="flex flex-col gap-3 bg-sky-50/70 px-6 py-4 text-xs text-slate-500 md:flex-row md:items-center md:justify-between">
          <p>
            Menampilkan <b className="text-slate-900">{rows.length}</b> dari{" "}
            <b className="text-slate-900">{fmt.format(summary.totalData)}</b> entri data primer
            posyandu
          </p>

          <nav aria-label="Paginasi" className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => goTo(page - 1)}
              disabled={page === 1}
              className="inline-flex items-center gap-1 rounded-md px-2.5 py-1.5 font-semibold text-slate-600 transition hover:bg-white disabled:opacity-40"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              Sebelumnya
            </button>

            {buildPages(page, totalPages).map((p, idx) =>
              p === "…" ? (
                <span key={`gap-${idx}`} className="px-1 text-slate-400">
                  …
                </span>
              ) : (
                <button
                  key={p}
                  type="button"
                  onClick={() => goTo(p)}
                  aria-current={p === page ? "page" : undefined}
                  className={`min-w-8 rounded-md px-2.5 py-1.5 font-bold transition ${
                    p === page
                      ? "bg-teal-800 text-white"
                      : "bg-white text-slate-700 hover:bg-slate-100"
                  }`}
                >
                  {p}
                </button>
              )
            )}

            <button
              type="button"
              onClick={() => goTo(page + 1)}
              disabled={page === totalPages}
              className="inline-flex items-center gap-1 rounded-md px-2.5 py-1.5 font-semibold text-slate-600 transition hover:bg-white disabled:opacity-40"
            >
              Berikutnya
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </nav>
        </div>
      </section>
    </div>
  );
}
